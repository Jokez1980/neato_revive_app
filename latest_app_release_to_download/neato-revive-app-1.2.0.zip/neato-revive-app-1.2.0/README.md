# Installing the Vacuula app on Android

* You need Android 7.0 or newer, a Vacuula server on your home network with your robot already set up, and your phone on the same Wi-Fi. No Developer mode or USB debugging is needed.

* Get the file: download or copy vacuula-x.y.z.apk to your phone.
* Open it: tap the file in your Downloads, the Files app or the browser.
* Allow the install: Android asks to allow apps from this source. Tap Settings, turn on Allow from this source, then go back.
* Install: tap Install. If Google Play Protect warns you, tap More details → Install anyway. The warning only appears because the app isn’t from Google Play.
* Connect to your server: open the app and tap Search network. If nothing is found, type your server’s IP address, for example 192.168.1.50. Then tap Test and Save.
* Notifications (optional): go to Settings → Notifications → Notify me, allow notifications, and set Android Settings → Apps → Vacuula → Battery to Unrestricted.

## FYI

* Updating: install the new APK over the old one. If it says “App not installed”, uninstall the old version first.

* Away from home: never expose the Vacuula server to the internet. It has no password. Use a VPN such as Tailscale instead.